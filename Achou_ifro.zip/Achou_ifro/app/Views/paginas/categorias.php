<!DOCTYPE html>
<html lang="pt-br">

<head>

    <!-- Define os caracteres para aceitar acentos e símbolos -->
    <meta charset="UTF-8">

    <!-- Adapta a página para celulares, tablets e computadores -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Título da página -->
    <title>Achados e Perdidos - Achou IFRO</title>


    <!-- Importa o Bootstrap para auxiliar na criação do layout -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Importa os ícones utilizados na página -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">


    <style>

        /* Remove as margens e os espaçamentos padrões */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Configura a aparência geral da página */
        body {
            background-color: #fffdf3;
            font-family: Arial, sans-serif;
            color: #123d68;
        }


        /* ==================================
           CABEÇALHO DA PÁGINA
        ================================== */

        /* Cria o espaço principal do cabeçalho */
        .cabecalho {
            background-color: #fff5d5;
            border: 1px solid #f0dfae;
            border-radius: 20px;
            margin: 20px;
            padding: 25px;

            /* Organiza os elementos lado a lado */
            display: flex;
            align-items: center;
            justify-content: space-between;

            overflow: hidden;
        }

        /* Organiza o ícone e o título */
        .titulo-area {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        /* Círculo amarelo atrás do ícone */
        .icone-principal {
            background-color: #ffdf79;
            color: #123d68;
            width: 110px;
            height: 110px;
            border-radius: 50%;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 55px;
        }

        /* Estiliza o título principal */
        .cabecalho h1 {
            font-size: 45px;
            font-weight: bold;
            color: #123d68;
            margin: 0;
        }

        /* Estiliza a descrição do cabeçalho */
        .cabecalho p {
            font-size: 17px;
            margin-top: 8px;
            color: #294d70;
        }

        /* Define o tamanho da imagem decorativa */
        .imagem-cabecalho {
            width: 280px;
            height: 140px;
            object-fit: contain;
        }


        /* ==================================
           CATEGORIAS
        ================================== */

        /* Organiza os botões de categorias */
        .categorias {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
            margin: 25px 20px;
        }

        /* Estiliza os botões das categorias */
        .btn-categoria {
            background-color: white;
            color: #123d68;
            border: 1px solid #d9e3e9;
            border-radius: 25px;

            padding: 10px 20px;
            font-size: 14px;

            cursor: pointer;
            transition: 0.3s;
        }

        /* Muda a cor quando o mouse passa sobre a categoria */
        .btn-categoria:hover {
            background-color: #fff0bd;
        }

        /* Destaca a categoria selecionada */
        .btn-categoria.ativo {
            background-color: #123d68;
            color: white;
            border-color: #123d68;
        }


        /* ==================================
           PESQUISA E ORDENAÇÃO
        ================================== */

        /* Organiza o campo de pesquisa e a ordenação */
        .filtros {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            margin: 20px;
        }

        /* Estiliza o campo de pesquisa */
        .pesquisa {
            width: 40%;
            border: 2px solid #d7e6ed;
            border-radius: 30px;
            padding: 10px 18px;
            background-color: white;

            display: flex;
            align-items: center;
        }

        /* Estiliza o ícone da lupa */
        .pesquisa i {
            font-size: 20px;
            margin-right: 12px;
        }

        /* Estiliza o campo onde o usuário digita */
        .pesquisa input {
            border: none;
            outline: none;
            width: 100%;
            color: #123d68;
        }

        /* Organiza o campo de ordenação */
        .ordenacao {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Estiliza as opções de ordenação */
        .ordenacao select {
            padding: 12px 20px;
            border: 2px solid #e2dfd2;
            border-radius: 30px;
            color: #123d68;
            background-color: white;
            cursor: pointer;
        }


        /* ==================================
           GRADE DOS OBJETOS
        ================================== */

        /* Organiza os cards em quatro colunas */
        .produtos {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            padding: 0 20px 30px;
        }

        /* Estiliza cada card de objeto */
        .card-produto {
            background-color: #fffef9;
            border: 1px solid #eddfb8;
            border-radius: 20px;
            padding: 12px;

            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);

            transition: 0.3s;
        }

        /* Efeito ao passar o mouse sobre o card */
        .card-produto:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.10);
        }

        /* Define o tamanho das imagens dos objetos */
        .imagem-produto {
            width: 100%;
            height: 160px;
            object-fit: cover;
            border-radius: 12px;
        }

        /* Permite colocar etiquetas sobre a imagem */
        .foto-container {
            position: relative;
        }


        /* ==================================
           STATUS DOS OBJETOS
        ================================== */

        /* Estilo geral das etiquetas */
        .status {
            position: absolute;
            top: 10px;
            left: 10px;

            padding: 7px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
        }

        /* Cor para objetos encontrados */
        .encontrada {
            background-color: #ffe18a;
            color: #34445a;
        }

        /* Cor para objetos perdidos */
        .perdida {
            background-color: #a9d9f1;
            color: #123d68;
        }


        /* ==================================
           BOTÃO DE FAVORITOS
        ================================== */

        /* Posiciona o coração no canto da imagem */
        .favorito {
            position: absolute;
            top: 10px;
            right: 10px;

            background: transparent;
            border: none;
            color: white;
            font-size: 25px;

            cursor: pointer;
            text-shadow: 1px 1px 3px #333;
        }

        /* Muda a cor do coração selecionado */
        .favorito.ativo {
            color: #e83e62;
        }


        /* ==================================
           INFORMAÇÕES DOS OBJETOS
        ================================== */

        /* Espaçamento das informações */
        .informacoes {
            padding: 12px 8px 3px;
        }

        /* Estiliza o nome do objeto */
        .informacoes h5 {
            font-size: 16px;
            font-weight: bold;
            color: #123d68;
            margin-bottom: 5px;
        }

        /* Estiliza a descrição */
        .descricao {
            color: #60758b;
            font-size: 14px;
            min-height: 40px;
            margin-bottom: 10px;
        }

        /* Organiza localização e data */
        .detalhe {
            display: flex;
            align-items: center;
            gap: 8px;

            color: #526b82;
            font-size: 14px;
            margin-bottom: 7px;
        }

        /* Estiliza os ícones das informações */
        .detalhe i {
            color: #123d68;
            font-size: 16px;
        }


        /* ==================================
           RODAPÉ DOS CARDS
        ================================== */

        /* Organiza a categoria e o botão */
        .rodape-card {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 12px;
            gap: 5px;
        }

        /* Estiliza o nome da categoria */
        .categoria {
            color: #927b37;
            font-size: 13px;

            display: flex;
            align-items: center;
            gap: 6px;
        }

        /* Estiliza o ícone da categoria */
        .categoria i {
            color: #123d68;
            font-size: 17px;
        }

        /* Estiliza o botão de detalhes */
        .btn-detalhes {
            background-color: #123d68;
            color: white;
            border: none;
            border-radius: 25px;

            padding: 10px 15px;
            font-size: 13px;

            text-decoration: none;
            white-space: nowrap;
            transition: 0.3s;
        }

        /* Efeito do botão ao passar o mouse */
        .btn-detalhes:hover {
            background-color: #245b8b;
            color: white;
        }

        /* Mensagem exibida quando não existem resultados */
        .sem-resultados {
            display: none;
            grid-column: 1 / -1;
            text-align: center;
            padding: 40px;
            color: #60758b;
        }


        /* ==================================
           RESPONSIVIDADE
        ================================== */

        /* Configura a página para tablets */
        @media (max-width: 1000px) {

            /* Mostra dois cards por linha */
            .produtos {
                grid-template-columns: repeat(2, 1fr);
            }

            .cabecalho h1 {
                font-size: 35px;
            }

        }

        /* Configura a página para celulares */
        @media (max-width: 600px) {

            .cabecalho {
                margin: 10px;
                padding: 15px;
            }

            /* Diminui o círculo do ícone */
            .icone-principal {
                width: 65px;
                height: 65px;
                font-size: 30px;
            }

            /* Diminui o título */
            .cabecalho h1 {
                font-size: 25px;
            }

            .cabecalho p {
                font-size: 12px;
            }

            /* Esconde a imagem decorativa */
            .imagem-cabecalho {
                display: none;
            }

            /* Organiza os filtros verticalmente */
            .filtros {
                flex-direction: column;
                align-items: stretch;
                margin: 15px;
            }

            .pesquisa {
                width: 100%;
            }

            .ordenacao {
                justify-content: space-between;
            }

            /* Mostra um card por linha */
            .produtos {
                grid-template-columns: 1fr;
                padding: 0 12px;
            }

            /* Diminui os espaços entre as categorias */
            .categorias {
                gap: 8px;
            }

            .btn-categoria {
                padding: 8px 13px;
                font-size: 12px;
            }

        }

    </style>

</head>


<body>


    <!-- ==================================
         CABEÇALHO PRINCIPAL
    ================================== -->

    <header class="cabecalho">

        <!-- Agrupa o ícone e o título -->
        <div class="titulo-area">

            <!-- Ícone principal da página -->
            <div class="icone-principal">
                <i class="bi bi-search"></i>
            </div>

            <!-- Nome e descrição -->
            <div>

                <h1>Achados e Perdidos</h1>

                <p>
                    Confira os objetos perdidos ou encontrados
                    no IFRO.
                </p>

            </div>

        </div>

        <!-- Imagem decorativa do cabeçalho -->
        <img src="img/achados-banner.png"
             alt="Ilustração de objetos encontrados"
             class="imagem-cabecalho">

    </header>



    <!-- ==================================
         BOTÕES DE CATEGORIAS
    ================================== -->

    <!-- Permite selecionar uma categoria de objeto -->
    <section class="categorias" aria-label="Filtrar por categoria">

        <!-- Mostra todos os objetos -->
        <button class="btn-categoria ativo" data-categoria="todos">
            <i class="bi bi-grid"></i> Todos
        </button>

        <!-- Filtra somente bolsas -->
        <button class="btn-categoria" data-categoria="bolsas">
            <i class="bi bi-backpack"></i> Bolsas
        </button>

        <!-- Filtra somente garrafas -->
        <button class="btn-categoria" data-categoria="garrafas">
            <i class="bi bi-cup"></i> Garrafas
        </button>

        <!-- Filtra somente chaves -->
        <button class="btn-categoria" data-categoria="chaves">
            <i class="bi bi-key"></i> Chaves
        </button>

        <!-- Filtra materiais escolares -->
        <button class="btn-categoria" data-categoria="materiais">
            <i class="bi bi-pencil"></i> Materiais
        </button>

        <!-- Filtra eletrônicos -->
        <button class="btn-categoria" data-categoria="eletronicos">
            <i class="bi bi-headphones"></i> Eletrônicos
        </button>

        <!-- Filtra outros objetos -->
        <button class="btn-categoria" data-categoria="outros">
            <i class="bi bi-box"></i> Outros
        </button>

    </section>



    <!-- ==================================
         PESQUISA E ORDENAÇÃO
    ================================== -->

    <section class="filtros">

        <!-- Campo de pesquisa -->
        <div class="pesquisa">

            <i class="bi bi-search"></i>

            <!-- Permite pesquisar pelo nome ou descrição -->
            <input type="text"
                   id="pesquisar"
                   placeholder="Buscar objetos..."
                   aria-label="Buscar objetos">

        </div>


        <!-- Opções para organizar os objetos -->
        <div class="ordenacao">

            <label for="ordenar">Ordenar por:</label>

            <select id="ordenar">

                <option value="recentes">Mais recentes</option>

                <option value="antigos">Mais antigos</option>

                <option value="nome">Nome</option>

            </select>

        </div>

    </section>



    <!-- ==================================
         LISTA DE OBJETOS
    ================================== -->

    <main class="produtos" id="listaProdutos">


        <!-- ==================================
             CARD 1 - MOCHILA PRETA
        ================================== -->

        <article class="card-produto"
                 data-nome="Mochila preta"
                 data-categoria="bolsas"
                 data-data="2025-05-12">

            <div class="foto-container">

                <!-- Imagem da mochila -->
                <img src="img/mochila.jpeg"
                     alt="Mochila preta"
                     class="imagem-produto">

                <!-- Informa que o objeto foi encontrado -->
                <span class="status encontrada">Encontrada</span>

                <!-- Botão de favorito -->
                <button class="favorito" aria-label="Adicionar mochila aos favoritos">
                    <i class="bi bi-heart"></i>
                </button>

            </div>


            <div class="informacoes">

                <h5>Mochila preta</h5>

                <p class="descricao">
                    Mochila preta com detalhes em cinza.
                </p>

                <!-- Localização do objeto -->
                <div class="detalhe">
                    <i class="bi bi-geo-alt-fill"></i>
                    Biblioteca
                </div>

                <!-- Data do registro -->
                <div class="detalhe">
                    <i class="bi bi-calendar-date"></i>
                    12/05/2025
                </div>


                <div class="rodape-card">

                    <span class="categoria">
                        <i class="bi bi-backpack-fill"></i>
                        Bolsas
                    </span>

                    <!-- Link para a página de detalhes -->
                    <a href="detalhes.php?id=1" class="btn-detalhes">
                        Ver detalhes <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

            </div>

        </article>



        <!-- ==================================
             CARD 2 - GARRAFA AZUL
        ================================== -->

        <article class="card-produto"
                 data-nome="Garrafa azul"
                 data-categoria="garrafas"
                 data-data="2025-05-10">

            <div class="foto-container">

                <img src="img/garrafa-azul.jpg"
                     alt="Garrafa azul"
                     class="imagem-produto">

                <span class="status perdida">Perdida</span>

                <button class="favorito" aria-label="Adicionar garrafa aos favoritos">
                    <i class="bi bi-heart"></i>
                </button>

            </div>


            <div class="informacoes">

                <h5>Garrafa azul</h5>

                <p class="descricao">
                    Garrafa de água azul, com tampa preta.
                </p>

                <div class="detalhe">
                    <i class="bi bi-geo-alt-fill"></i>
                    Laboratório 06
                </div>

                <div class="detalhe">
                    <i class="bi bi-calendar-date"></i>
                    10/05/2025
                </div>


                <div class="rodape-card">

                    <span class="categoria">
                        <i class="bi bi-cup"></i>
                        Garrafas
                    </span>

                    <a href="detalhes.php?id=2" class="btn-detalhes">
                        Ver detalhes <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

            </div>

        </article>



        <!-- ==================================
             CARD 3 - CHAVES
        ================================== -->

        <article class="card-produto"
                 data-nome="Chaves com chaveiro"
                 data-categoria="chaves"
                 data-data="2025-05-08">

            <div class="foto-container">

                <img src="img/chaves.jpg"
                     alt="Chaves com chaveiro"
                     class="imagem-produto">

                <span class="status encontrada">Encontrada</span>

                <button class="favorito" aria-label="Adicionar chaves aos favoritos">
                    <i class="bi bi-heart"></i>
                </button>

            </div>


            <div class="informacoes">

                <h5>Chaves com chaveiro</h5>

                <p class="descricao">
                    Chaveiro azul com três chaves.
                </p>

                <div class="detalhe">
                    <i class="bi bi-geo-alt-fill"></i>
                    Banheiro
                </div>

                <div class="detalhe">
                    <i class="bi bi-calendar-date"></i>
                    08/05/2025
                </div>


                <div class="rodape-card">

                    <span class="categoria">
                        <i class="bi bi-key-fill"></i>
                        Chaves
                    </span>

                    <a href="detalhes.php?id=3" class="btn-detalhes">
                        Ver detalhes <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

            </div>

        </article>



        <!-- ==================================
             CARD 4 - FONE DE OUVIDO
        ================================== -->

        <article class="card-produto"
                 data-nome="Fone de ouvido"
                 data-categoria="eletronicos"
                 data-data="2025-05-05">

            <div class="foto-container">

                <img src="img/fone.jpg"
                     alt="Fone de ouvido preto"
                     class="imagem-produto">

                <span class="status perdida">Perdida</span>

                <button class="favorito" aria-label="Adicionar fone aos favoritos">
                    <i class="bi bi-heart"></i>
                </button>

            </div>


            <div class="informacoes">

                <h5>Fone de ouvido</h5>

                <p class="descricao">
                    Fone de ouvido preto com estojo.
                </p>

                <div class="detalhe">
                    <i class="bi bi-geo-alt-fill"></i>
                    Cit
                </div>

                <div class="detalhe">
                    <i class="bi bi-calendar-date"></i>
                    05/05/2025
                </div>


                <div class="rodape-card">

                    <span class="categoria">
                        <i class="bi bi-headphones"></i>
                        Eletrônicos
                    </span>

                    <a href="detalhes.php?id=4" class="btn-detalhes">
                        Ver detalhes <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

            </div>

        </article>



        <!-- ==================================
             CARD 5 - CADERNO
        ================================== -->

        <article class="card-produto"
                 data-nome="Caderno universitário"
                 data-categoria="materiais"
                 data-data="2025-05-03">

            <div class="foto-container">

                <img src="img/caderno.jpg"
                     alt="Caderno universitário"
                     class="imagem-produto">

                <span class="status encontrada">Encontrada</span>

                <button class="favorito" aria-label="Adicionar caderno aos favoritos">
                    <i class="bi bi-heart"></i>
                </button>

            </div>


            <div class="informacoes">

                <h5>Caderno universitário</h5>

                <p class="descricao">
                    Caderno azul com capa de desenho.
                </p>

                <div class="detalhe">
                    <i class="bi bi-geo-alt-fill"></i>
                    Sala 05
                </div>

                <div class="detalhe">
                    <i class="bi bi-calendar-date"></i>
                    03/05/2025
                </div>


                <div class="rodape-card">

                    <span class="categoria">
                        <i class="bi bi-pencil"></i>
                        Materiais
                    </span>

                    <a href="detalhes.php?id=5" class="btn-detalhes">
                        Ver detalhes <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

            </div>

        </article>



        <!-- ==================================
             CARD 6 - BOLSA PRETA
        ================================== -->

        <article class="card-produto"
                 data-nome="Bolsa preta"
                 data-categoria="bolsas"
                 data-data="2025-05-01">

            <div class="foto-container">

                <img src="img/bolsa-preta.jpg"
                     alt="Bolsa preta"
                     class="imagem-produto">

                <span class="status perdida">Perdida</span>

                <button class="favorito" aria-label="Adicionar bolsa aos favoritos">
                    <i class="bi bi-heart"></i>
                </button>

            </div>


            <div class="informacoes">

                <h5>Bolsa preta</h5>

                <p class="descricao">
                    Bolsa preta de mão, com detalhes dourados.
                </p>

                <div class="detalhe">
                    <i class="bi bi-geo-alt-fill"></i>
                    Copa
                </div>

                <div class="detalhe">
                    <i class="bi bi-calendar-date"></i>
                    01/05/2025
                </div>


                <div class="rodape-card">

                    <span class="categoria">
                        <i class="bi bi-backpack-fill"></i>
                        Bolsas
                    </span>

                    <a href="detalhes.php?id=6" class="btn-detalhes">
                        Ver detalhes <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

            </div>

        </article>



        <!-- ==================================
             CARD 7 - GARRAFA ROSA
        ================================== -->

        <article class="card-produto"
                 data-nome="Garrafa rosa"
                 data-categoria="garrafas"
                 data-data="2025-04-28">

            <div class="foto-container">

                <img src="img/garrafa-rosa.jpg"
                     alt="Garrafa rosa"
                     class="imagem-produto">

                <span class="status encontrada">Encontrada</span>

                <button class="favorito" aria-label="Adicionar garrafa aos favoritos">
                    <i class="bi bi-heart"></i>
                </button>

            </div>


            <div class="informacoes">

                <h5>Garrafa rosa</h5>

                <p class="descricao">
                    Garrafa térmica rosa com tampa branca.
                </p>

                <div class="detalhe">
                    <i class="bi bi-geo-alt-fill"></i>
                    Auditório
                </div>

                <div class="detalhe">
                    <i class="bi bi-calendar-date"></i>
                    28/04/2025
                </div>


                <div class="rodape-card">

                    <span class="categoria">
                        <i class="bi bi-cup"></i>
                        Garrafas
                    </span>

                    <a href="detalhes.php?id=7" class="btn-detalhes">
                        Ver detalhes <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

            </div>

        </article>



        <!-- ==================================
             CARD 8 - OUTROS OBJETOS
        ================================== -->

        <article class="card-produto"
                 data-nome="Guarda-chuva"
                 data-categoria="outros"
                 data-data="2025-04-25">

            <div class="foto-container">

                <img src="img/guarda-chuva.jpg"
                     alt="Guarda-chuva azul"
                     class="imagem-produto">

                <span class="status perdida">Perdida</span>

                <button class="favorito" aria-label="Adicionar guarda-chuva aos favoritos">
                    <i class="bi bi-heart"></i>
                </button>

            </div>


            <div class="informacoes">

                <h5>Guarda-chuva</h5>

                <p class="descricao">
                    Guarda-chuva azul escuro com cabo preto.
                </p>

                <div class="detalhe">
                    <i class="bi bi-geo-alt-fill"></i>
                    Sala 20
                </div>

                <div class="detalhe">
                    <i class="bi bi-calendar-date"></i>
                    25/04/2025
                </div>


                <div class="rodape-card">

                    <span class="categoria">
                        <i class="bi bi-box"></i>
                        Outros
                    </span>

                    <a href="detalhes.php?id=8" class="btn-detalhes">
                        Ver detalhes <i class="bi bi-arrow-right"></i>
                    </a>

                </div>

            </div>

        </article>


        <!-- Mensagem que aparece quando nenhum objeto é encontrado -->
        <div class="sem-resultados" id="semResultados">

            <i class="bi bi-search" style="font-size: 35px;"></i>

            <h5>Nenhum objeto encontrado!</h5>

            <p>Tente pesquisar outro nome ou selecionar outra categoria.</p>

        </div>

    </main>



    <!-- ==================================
         JAVASCRIPT
         Pesquisa, categorias, ordenação e favoritos
    ================================== -->

    <script>


        // ==================================
        // ELEMENTOS DA PÁGINA
        // ==================================

        // Seleciona o campo de pesquisa
        const pesquisar = document.getElementById("pesquisar");

        // Seleciona todos os cards
        const listaProdutos = document.getElementById("listaProdutos");

        // Seleciona o campo de ordenação
        const ordenar = document.getElementById("ordenar");

        // Seleciona a mensagem de nenhum resultado
        const semResultados = document.getElementById("semResultados");

        // Guarda a categoria selecionada
        let categoriaSelecionada = "todos";


        // ==================================
        // FUNÇÃO PARA FILTRAR OS OBJETOS
        // ==================================

        // Essa função verifica a pesquisa e a categoria escolhida
        function filtrarObjetos() {

            // Pega o texto digitado pelo usuário
            const texto = pesquisar.value.toLowerCase();

            // Seleciona todos os cards da página
            const cards = document.querySelectorAll(".card-produto");

            // Começa a contagem de objetos encontrados
            let encontrados = 0;


            // Percorre todos os cards
            cards.forEach(card => {

                // Pega o nome do objeto
                const nome = card.dataset.nome.toLowerCase();

                // Pega a categoria do objeto
                const categoria = card.dataset.categoria;

                // Pega as informações escritas no card
                const descricao = card.innerText.toLowerCase();


                // Verifica se o objeto corresponde à pesquisa
                const correspondePesquisa =
                    nome.includes(texto) || descricao.includes(texto);


                // Verifica se corresponde à categoria selecionada
                const correspondeCategoria =
                    categoriaSelecionada === "todos" ||
                    categoria === categoriaSelecionada;


                // Se corresponder aos dois filtros, mostra o card
                if (correspondePesquisa && correspondeCategoria) {

                    card.style.display = "";

                    encontrados++;

                } else {

                    // Caso contrário, esconde o card
                    card.style.display = "none";

                }

            });


            // Se não houver resultados, mostra uma mensagem
            if (encontrados === 0) {

                semResultados.style.display = "block";

            } else {

                semResultados.style.display = "none";

            }

        }


        // Detecta quando o usuário digita na pesquisa
        pesquisar.addEventListener("input", filtrarObjetos);



        // ==================================
        // FILTRO DE CATEGORIAS
        // ==================================

        // Seleciona todos os botões de categorias
        const botoesCategoria = document.querySelectorAll(".btn-categoria");


        // Percorre os botões
        botoesCategoria.forEach(botao => {

            // Detecta quando o usuário clica em uma categoria
            botao.addEventListener("click", function () {

                // Remove a seleção dos outros botões
                botoesCategoria.forEach(item => {
                    item.classList.remove("ativo");
                });

                // Destaca o botão que foi selecionado
                this.classList.add("ativo");

                // Guarda a categoria escolhida
                categoriaSelecionada = this.dataset.categoria;

                // Atualiza os objetos que aparecem na página
                filtrarObjetos();

            });

        });



        // ==================================
        // FUNÇÃO DE ORDENAÇÃO
        // ==================================

        // Detecta quando o usuário muda a ordenação
        ordenar.addEventListener("change", function () {

            // Seleciona todos os cards
            const cards = Array.from(
                listaProdutos.querySelectorAll(".card-produto")
            );


            // Verifica qual opção foi selecionada
            if (this.value === "recentes") {

                // Organiza do mais recente para o mais antigo
                cards.sort((a, b) =>
                    new Date(b.dataset.data) - new Date(a.dataset.data)
                );

            } else if (this.value === "antigos") {

                // Organiza do mais antigo para o mais recente
                cards.sort((a, b) =>
                    new Date(a.dataset.data) - new Date(b.dataset.data)
                );

            } else {

                // Organiza os objetos em ordem alfabética
                cards.sort((a, b) =>
                    a.dataset.nome.localeCompare(b.dataset.nome)
                );

            }


            // Coloca os cards novamente na página na ordem escolhida
            cards.forEach(card => {
                listaProdutos.insertBefore(card, semResultados);
            });

        });



        // ==================================
        // FUNÇÃO DE FAVORITOS
        // ==================================

        // Seleciona todos os botões de coração
        document.querySelectorAll(".favorito").forEach(botao => {

            // Detecta quando o usuário clica no coração
            botao.addEventListener("click", function () {

                // Adiciona ou remove a classe de favorito
                this.classList.toggle("ativo");

                // Seleciona o ícone do coração
                const icone = this.querySelector("i");


                // Verifica se o objeto foi marcado como favorito
                if (this.classList.contains("ativo")) {

                    // Troca o coração vazio pelo preenchido
                    icone.classList.replace(
                        "bi-heart",
                        "bi-heart-fill"
                    );

                } else {

                    // Volta para o coração vazio
                    icone.classList.replace(
                        "bi-heart-fill",
                        "bi-heart"
                    );

                }

            });

        });


    </script>


</body>

</html>